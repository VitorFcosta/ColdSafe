# ColdSafe — Direção visual

Aprovado em 09/09/2026 na tarefa CS-26.

## Direção e composição

- Direção: Caderno de bancada.
- Composição: B — Gráfico ampliado.
- Superfície operacional: reconhecer estado, atualidade e tendência.
- Fundo marfim, texto verde escuro, linhas finas e pouca decoração.
- Temperatura dominante, umidade secundária e horário terciário.
- Tipografia sem serifa de sistema, com algarismos tabulares.

## Referências aprovadas

Caminhos relativos a este documento:

- Desktop: .impeccable/mocks/review/desktop.png
- Mobile: .impeccable/mocks/review/mobile-v2.png
- Estados: .impeccable/mocks/review/estados-v2.png
- Registro: .impeccable/mocks/review/revisao.json

Viewports de referência: desktop 1440 × 900 e mobile 390 × 844.
As dimensões dos arquivos raster diferem desses viewports.
A pasta .impeccable é local e ignorada pelo Git; as imagens finais também estão anexadas à CS-26 no Notion.

## Paleta base

| Uso | Cor |
| --- | --- |
| Fundo | #FAF9F5 |
| Texto principal | #003A36 |
| Fundo do estado normal | #EAF2EC |
| Texto do estado normal | #004039 |
| Controle selecionado | #00785F |
| Texto do controle selecionado | #FFFFFF |

Atenção usa âmbar; criticidade usa vermelho.
Todos os estados combinam texto, ícone e cor.

## Organização

Desktop:
1. Produto, ambiente e dispositivo.
2. Faixa de estado com a idade da leitura.
3. Temperatura, umidade e horário em uma linha.
4. Histórico amplo com seleção de período.
5. Diagnóstico técnico recolhível.

Mobile:
- Uma coluna, sem a numeração da margem.
- Estado e atualidade permanecem juntos.
- Temperatura acima de umidade e horário.
- Dados atuais aparecem antes do histórico.
- Permitir rolagem vertical; evitar rolagem horizontal.
- Não reduzir texto ou controles para forçar tudo na primeira tela.

## Dados e estados

- Carregamento inicial: skeleton, sem valores inventados.
- Sem dados: traços e orientação para iniciar a simulação.
- Normal, atenção e crítico: seguir o estado retornado pelo backend.
- Desatualizado: mostrar “Última leitura conhecida” e sua idade; não apresentar “Normal” como diagnóstico atual.
- Erro de serviço: informar indisponibilidade da consulta.
- Falha do histórico: preservar a leitura atual válida.
- Histórico vazio: informar ausência de leituras naquele período; isso não equivale a erro de serviço.

Atualização por polling a cada 5 segundos.
Uma consulta bem-sucedida não significa que chegou uma leitura nova.
Formatar received_at no horário local e identificar esse contexto.

## Histórico

- Períodos: 15 min, 1 h, 6 h e 24 h; inicial: 1 h.
- Mostrar somente as amostras retornadas pela API.
- Resumo: “Amostras exibidas: entre …”.
- Não afirmar extremos de todo o período quando os dados são limitados.
- Ajustar o eixo para abranger todos os valores e limites demonstrativos.
- Não prolongar a curva depois da última leitura.
- Reduzir a quantidade de rótulos temporais no mobile.

## Acessibilidade e validação

- Alvos interativos de pelo menos 44 × 44 CSS px.
- Foco visível e operação por teclado.
- Resumo textual e acesso por teclado aos dados do gráfico.
- Respeitar preferência por redução de movimento.
- Anunciar mudanças de estado sem anunciar cada atualização numérica.
- Validar contraste, responsividade e controles na implementação.

Os mockups aprovam direção e composição.
Curvas ilustrativas não substituem dados e escalas numéricas reais.
